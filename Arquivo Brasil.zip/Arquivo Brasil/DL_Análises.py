# Importação das Bibliotecas
from operator import index
import pandas as pd

# Lendo o arquivo csv e armazenando uma variável

brasil_base = pd.read_csv('brasil.csv')

# Transformando arquivo em DataFrame

brasil_df = pd.DataFrame(brasil_base)

# Reduzindo o número de colunas para aquelas essenciais à análise

brasil_reuzido = brasil_df[['ano', 'expectativa_vida', 'fecundidade_total', 'mortalidade_1', 'mortalidade_5', 'prob_sobrevivencia_40', 'prob_sobrevivencia_60', 'prop_pobreza_extrema', 'renda_pc', 'populacao_urbana', 'populacao_rural', 'indice_escolaridade', 'idhm']]

# Salvando o arquivolimpo em formato Excel

brasil_reuzido.to_excel('brasil_reuzido.xlsx')

print(brasil_reuzido)
